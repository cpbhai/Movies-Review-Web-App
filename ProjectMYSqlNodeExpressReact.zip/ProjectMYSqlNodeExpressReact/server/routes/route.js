const router = require('express').Router()
const db = require('../db')
const multer = require('multer')

const fs = require('fs')
const { promisify } = require('util')
const pipeline = promisify(require('stream').pipeline)

const upload = multer();
router.post('/api/insert', upload.single('CustomHarshName'), async (req, res) => {

    //console.log("hello ", req.body)
    //console.log('Kello ', __dirname)
    //console.log('ABC')
    const fileName = Date.now() + req.body.movieName + req.file.detectedFileExtension;
    //console.log('DEF')
    await pipeline(req.file.stream, fs.createWriteStream(`${__dirname}/../../client/public/images/${fileName}`))
    //console.log('EFG')
    const sqlIns = "INSERT INTO movie_reviews(movieName, image, movieReview) VALUES(?, ?, ?);"
    db.query(sqlIns, [req.body.movieName, fileName, req.body.movieReview], (err, result) => {
        if (err) console.log('Error int Route.js ', err);
        else {
            //console.log(result)
            res.send('Successfully Saved')
        }
    })
})

router.get('/api/get', (req, res) => {
    const sqlSel = "SELECT * FROM movie_reviews ORDER BY id DESC;"
    db.query(sqlSel, (err, result) => {
        if (err) console.log('Error int Route.js ', err);
        else {
            //console.log(result)
            res.send(result)
        }
    })
})

module.exports = router