const express = require('express')
const app = express()
const bodyParser=require('body-parser')
const cors=require('cors')
const router = require('./routes/route')

//Middlewares
app.use(express.json())
app.use(cors())
app.use(bodyParser.urlencoded({extended: true}))
app.use(router)


app.listen(3001, () => {
    console.log('Server Running on 3001')
})