import React, { useState, useEffect } from 'react';
import "../App.css"
import Axios from 'axios';
import swal from 'sweetalert';
import M from 'materialize-css'

const Add = () => {
    const [movieName, setMovieName] = useState("")
    const [movieReview, setMovieReview] = useState("")
    const [photo, setPhoto] = useState("")
    const [movieReviewList, setMovieReviewList] = useState([])

    useEffect(() => {
        Axios.get('http://localhost:3001/api/get')
            .then((result) => {
                setMovieReviewList(result.data);
            })
    }, [])

    const handleSubmit = (event) => {
        event.preventDefault();
        //swal("Congrats!", "Review Submitted!", "success");
        //swal("Congratulations", "Review Added Successfully", "success");
        // setMovieReviewList([{ movieName, movieReview }, ...movieReviewList])
        // setMovieName('');
        // setMovieReview('');
        M.toast({ html: "Saving...", classes: "#43a047 green darken-1" })
        setTimeout(function () {submitData();},2000)
    }

    const submitData = () => {
        swal("Congratulations", 'Successfully Saved', "success")
        setTimeout(function () {
            //console.log('Munni ', photo)
            const data = new FormData();
            data.append("CustomHarshName", photo)
            data.append('movieReview', movieReview)
            data.append('movieName', movieName)
            //console.log('The ', data)
            Axios.post('http://localhost:3001/api/insert', data)
                .then(res => {
                    setMovieReviewList([{ movieName, photo, movieReview }, ...movieReviewList])
                    setMovieName('');
                    setMovieReview('');
                }).catch(err => {
                    console.log(err)
                })
        }, 2000)
    }

    return (
        <div>
            <h1>Movie Review App</h1>
            <div className="add-rev">
                <form className="form" id="form" onSubmit={handleSubmit} encType="multipart/form-data">
                    <input type="text" name="movieName" required
                        value={movieName} onChange={(e) => setMovieName(e.target.value)} placeholder="Enter Movie Name" />

                    <input type="file" name='photo' accept=".png,.jpg,.jpeg,.jfif" onChange={(e) => setPhoto(e.target.files[0])} required />

                    <input type="text" name="movieReview" required
                        value={movieReview} onChange={(e) => setMovieReview(e.target.value)} placeholder="Enter Review" />

                    <button style={{ color: "white", backgroundColor: "green", border: "none", fontSize: "30px" }}>submit</button>
                    <span style={{ marginTop: "30px" }}></span>
                    {
                        movieReviewList.map((val) => {
                            return (
                                <div key={val.id} className="card" style={{ width: "310px", border: "1px solid red" }}>
                                    <img src={'/images/' + val.image} alt={'Some Error'} style={{ objectFit:"cover", width: "100px", height: "100px",marginTop:"10px" }} />
                                    <h4>{val.movieName}</h4>
                                    <h5>{val.movieReview}</h5>
                                </div>
                            )
                        })
                    }
                </form>
            </div>
        </div>
    )
}
export default Add
